

const numero = parseInt(prompt("ingresa un numero entre 1 y 20: "));

if (numero>20 || numero<1){

    alert("numero fuera de parametro");

}else{

    for (let i = 1; i <= numero; i++) {

        let multi=numero*i; 

        console.log(`${numero} X ${i} =${multi} \n`);          

    }

    

const factorial = numero => {

    if (numero < 0) numero = numero * -1;

    if (numero <= 0) return 1;

    let factorial = 1;

    while (numero > 1) {

        factorial = factorial * numero;

        numero--;

    }

    return factorial;

}



for (var x = 0; x < numero; x++) {
    console.log(`El factorial de ${x} es ${factorial(x)}`);
}

console.log(`El factorial de ${x} es ${factorial(x)}`);
}

