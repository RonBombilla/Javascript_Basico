$(document).ready(function() {
    $('button').on('click', function() {
        $.ajax({
            type: "GET",
            url: "https://www.feriadosapp.com/api/holidays.json",
            dataType: "json",
            success: function(datosApi) {
                datosApi.data.forEach(element => {
                    $('#resultado')
                        .append(`<tr>
        
                        <td>${element.id}</td>
                    
                        <td>${element.date}</td>
                    
                        <td>${element.title}</td>
                    
                        <td>${element.extra}</td>
                    
                        <td>${element.law}</td>

                        <td>${element.law_id}</td>
                    
                        </tr>`);
                })
            },
            error: function(error) {
                //si algo sale mal, se agrega la funcionalidad aquí.
            },
        });
    });
});

/*
function Carta(numero, pinta) {
    this.numero = numero;
    this.pinta = pinta;
}

var corazones = new Carta(4, 'corazones');

class Naipe {
    consttructor(pinta, numero) {
        this.numero = numero;
        this.pinta = pinta;
    }

    nuevoNaipe() {
        return true;
    }
}

class Circulo {
    constructor(r) {
        this.r = r;
    }
    calcularArea() {
        return this.r * this.r * Math.PI;
    }
    calcularPerimetro() {
        return this.r * Math.PI * 2;
    }
}

class Rectangulo {
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }

    calcularArea() {
        return this.x * this.y;
    }

    calcularPerimetro() {
        return (this.x + this.x) * 2;
    }
}

const circulo = new Circulo(2);

console.log(circulo.calcularArea());
console.log(circulo.calcularPerimetro());

const rectangulo = new Rectangulo(4, 6);

console.log(rectangulo.calcularArea());
console.log(rectangulo.calcularPerimetro());

class Perro {
    constructor(raza) {
        this._raza = raza;
    }

    get raza() {
        return this._raza;
    }

    set raza(nueva_raza) {
        this._raza = nueva_raza;
    }
}

const perro = new Perro('Doberman');

console.log(perro.raza);

perro.raza;
perro.raza = 'Pastor Belga';

console.log(perro.raza);*/