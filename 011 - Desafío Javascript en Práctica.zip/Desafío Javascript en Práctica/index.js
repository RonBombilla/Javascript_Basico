//var btnsubmit = document.getElementById("boton");
var form = document.getElementById("formulario")


form.addEventListener("submit", (event) => {
    var nom = document.getElementById("nombre");
    var asun = document.getElementById("asunto");
    var msj = document.getElementById("mensaje");

    const verification = /[a-zA-Z]/i;

    event.preventDefault();
    console.log(nom.value, asun.value, msj.value)

    if (!(verification.test(nom.value)) || nom.value == " ") {
        document.querySelector('.errorNombre').innerHTML = "El nombre es requerido";
    }
    if (!(verification.test(asun.value)) || asun.value == " ") {
        document.querySelector('.errorAsunto').innerHTML = "El asunto es requerido";
    }
    if (!(verification.test(msj.value)) || msj.value == " ") {
        document.querySelector('.errorMensaje').innerHTML = "El mensaje es requerido";
    };
    if (verification.test(nom.value) && verification.test(asun.value) && verification.test(msj.value)) {
        document.querySelector('.resultado').innerHTML = "Formulario enviado con exito";
    };
});