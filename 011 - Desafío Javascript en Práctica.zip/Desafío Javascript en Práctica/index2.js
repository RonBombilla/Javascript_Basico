var btn1 = document.getElementById("btn-1");
var btn2 = document.getElementById("btn-2");
var btn3 = document.getElementById("btn-3");
var btn4 = document.getElementById("btn-4");
var btn5 = document.getElementById("btn-5");
var btn6 = document.getElementById("btn-6");

btn1.addEventListener('click', (event) => {
    event.preventDefault();
    document.getElementById('caja').style.backgroundColor = "#e53e3e";
});

btn2.addEventListener('click', (event) => {
    event.preventDefault();
    document.getElementById('caja').style.backgroundColor = "#dd6b20";
});

btn3.addEventListener('click', (event) => {
    event.preventDefault();
    document.getElementById('caja').style.backgroundColor = "#faf089";
});

btn4.addEventListener('click', (event) => {
    event.preventDefault();
    document.getElementById('caja').style.backgroundColor = "#48bb78";
});

btn5.addEventListener('click', (event) => {
    event.preventDefault();
    document.getElementById('caja').style.backgroundColor = "#81e6d9";
});

btn6.addEventListener('click', (event) => {
    event.preventDefault();
    document.getElementById('caja').style.backgroundColor = "#d53f8c";
});