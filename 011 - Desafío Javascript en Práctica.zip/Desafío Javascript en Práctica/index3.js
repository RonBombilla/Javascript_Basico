var sumar = document.getElementById("btn-sumar");
var restar = document.getElementById("btn-restar");
var resultado = document.getElementsByTagName("resultado");

sumar.addEventListener('click', (event) => {

    var num1 = parseFloat(document.querySelector("#valor1").value);
    var num2 = parseFloat(document.querySelector("#valor2").value);
    var suma_res = num1 + num2;
    if (suma_res < 0) {
        suma_res = 0;
    }
    document.querySelector('.resultado').innerHTML = "El resultado es: " + suma_res;
});

restar.addEventListener('click', (event) => {

    var num1 = parseFloat(document.querySelector("#valor1").value);
    var num2 = parseFloat(document.querySelector("#valor2").value);
    var resta_res = num1 - num2;
    if (resta_res < 0) {
        resta_res = 0;
    }
    document.querySelector('.resultado').innerHTML = "el resultado es: " + resta_res;
});