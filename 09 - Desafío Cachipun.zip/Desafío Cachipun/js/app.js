const op_intentos = (prompt("¿Cuantas veces deseas intentarlo?: "));
var num_intentos = 0;
var ganador_jug = 0;
var perdedor_jug = 0;
var iguales = 0;

function resultado_final(resultado) {
    while (num_intentos < op_intentos) {
        num_intentos++
        if (resultado === victoria) {
            ganador_jug++;
        }
        if (resultado === derrota) {
            perdedor_jug++;
        }
        if (resultado === empate) {
            iguales++;
        }
    }

    if (num_intentos === op_intentos) {
        alert("fin del juego");
        if (ganador_jug > perdedor_jug) {
            alert("Felicidades, le haz ganado a la máquina")
        }
        if (ganador_jug < perdedor_jug) {
            alert("Que lastima, te ha ganado la máquina")
        }
        if (ganador_jug === perdedor_jug) {
            alert("Es un empate")
        }
    }
}

const op_piedra = 0;
const op_papel = 1;
const op_tijera = 2;

const derrota = 2;
const victoria = 1;
const empate = 0;

const piedra = document.getElementById("piedra");
const papel = document.getElementById("papel");
const tijera = document.getElementById("tijera");
const salir = document.getElementById("salir");

piedra.addEventListener("click", () => {
    jugador(op_piedra);
});

papel.addEventListener("click", () => {
    jugador(op_papel);
});

tijera.addEventListener("click", () => {
    jugador(op_tijera);
});

salir.addEventListener("click", () => {
    alert("Hasta la próxima");
});

$(document).ready(function() {
    $("#salir").on("click", function() {
        $('#botones').hide();
    });
});

function jugador(jugada) {
    var op_maquina = Math.floor(Math.random() * 3);
    var resultado = calc_resultado(jugada, op_maquina);

    switch (resultado) {
        case empate:
            alert("empate")
            break;
        case victoria:
            alert("Felicidades, haz ganado!!!")
            break;
        case derrota:
            alert("Que lastima, Haz perdido...")
            break;
    };
};

function calc_resultado(jugada, op_maquina) {
    if (jugada === op_maquina) {
        return empate;

    } else if (jugada === op_piedra) {
        if (op_maquina === op_papel) return derrota;
        if (op_maquina === op_tijera) return victoria;

    } else if (jugada === op_papel) {
        if (op_maquina === op_tijera) return derrota;
        if (op_maquina === op_piedra) return victoria;

    } else if (jugada === op_tijera) {
        if (op_maquina === op_piedra) return derrota;
        if (op_maquina === op_papel) return victoria;
    };
};