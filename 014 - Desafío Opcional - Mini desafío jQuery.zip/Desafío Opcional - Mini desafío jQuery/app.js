$(document).ready(function() {
    let presionar = $('#presionar');

    presionar.click(function() {
        $('#cambiar').addClass('cambiar');
    });
});


$(document).ready(function() {
    let boton = $('#btn');
    let menu = $('#list');

    boton.click(function() {
        menu.fadeToggle("slow", "linear");
    });
});



$(document).ready(function() {
    $("#red-box").mouseover(function() {
        $('.uno').css("background-color", "yellow");
        $('.dos').css("background-color", "pink");

    });

    $("#red-box").mouseout(function() {
        $('.uno').css("background-color", "transparent");
        $('.dos').css("background-color", "transparent");
    });
});