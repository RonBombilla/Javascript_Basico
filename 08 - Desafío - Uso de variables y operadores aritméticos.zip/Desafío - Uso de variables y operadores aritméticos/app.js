//Suma, resta, multiplicación, división y Módulo de dos números---------------------------------

function operaciones_basicas(){
 	let num1 = parseFloat(prompt("Ingrese un múmero mayor a cero : "));
	let num2 = parseFloat(prompt("Ingrese otro múmero mayor a cero: "));

	let suma = num1 + num2;
	let resta = num1 - num2;
	let multi = num1 * num2;
	let divi = num1 / num2;
	let modulo = num1 % num2;

	console.log("La suma de ambos números es: "+suma);
	console.log("La resta de ambos números es: "+resta);
	console.log("La multiplicación de ambos números es: "+multi);
	console.log("La división de ambos números es: "+divi);
	console.log("El modulo de ambos números es: "+modulo);
};
//Conversión de temperatura de grados Celsius a Farenheit y Kelvin------------------------------

function conversor_temperatura(){
	let celsius = parseFloat(prompt("Ingrese grados Celsius: "));
	let Farenheit = celsius + "° Celsius son " + (celsius * 9/5) + 32 + "° Farenheit";
	let kelvin = celsius + "° Celsius son " + (celsius + 273.15) + "° Kelvin";

	console.log(Farenheit);
	console.log(kelvin);

};

//Conversor de "x" días en años, meses, semanas y días restantes--------------------------------


function conversor_dias(){
	var dias = parseFloat(prompt("Ingresar cantidad de días: "));

	var year = Math.round(dias/365);
	var month =Math.round(((dias)-year*365)/30);
	var week = Math.round((((dias)-year*365)-month*30)/7);
	var day = Math.round(((((dias)-year*365)-month*30)-week*7)/1);

	console.log("En "+ dias + " días hay: "+ year + " año/s, " + month + " mes/es, " + week + " semana/s y " + day + " días." );
};

//Suma y Promedio de 5 números ingreados por usuario--------------------------------------------

function suma_promedio_5N(){
	const miArray = new Array();
	let suma = 0;

	// bucle para ingresar 5 números
	for(var i=1;i<=5;i++)
	{
	    let name = parseFloat(prompt("Introduce un numero"));
	    miArray.push(name);
	};

	//Bucle para suma de los 5 números
	miArray.forEach(function(numero){
	        suma += numero;
	    });

	//promedio de números sumados
	let promedio = suma / miArray.length;

	console.log("La suma de los 5 números ingresados es: " + suma);
	console.log("Y el promedio de estos es: " + promedio);
};



